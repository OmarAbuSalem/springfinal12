
# 📚 Spring Boot Homework: Author & Book Management App

This is a simple Spring Boot web application that allows users to manage **authors and their books**.

---

## 🎯 Project Goals

This app was created as a homework assignment to demonstrate:

- Spring Boot fundamentals
- MVC pattern
- Form input handling and validation
- CRUD operations (Create, Read, Update, Delete)
- Using in-memory data structures

---

## 🚀 Features

### 🔹 Authors

- Add new authors
- View all authors
- View author details (with their books)
- Edit and delete authors

### 🔹 Books

- Add new books (select author)
- View all books with author names
- View book details (with link to author)
- Edit and delete books

---

## 🌐 URLs

| Feature              | URL                        |
|---------------------|----------------------------|
| Home Page           | `/`                        |
| List Authors        | `/authors`                 |
| Add Author          | `/authors/new`             |
| Author Details      | `/authors/{id}`            |
| Edit Author         | `/authors/edit/{id}`       |
| Delete Author       | `/authors/delete/{id}`     |
| List Books          | `/books`                   |
| Add Book            | `/books/new`               |
| Book Details        | `/books/{id}`              |
| Edit Book           | `/books/edit/{id}`         |
| Delete Book         | `/books/delete/{id}`       |

---

## ⚙️ How to Run

Make sure you have:

- Java 21+ installed
- Apache Maven installed

### 📦 Build and Run

```bash
cd springbootsfile
mvn clean package
java -jar target/springbootsfile-0.0.1-SNAPSHOT.jar


go to  http://localhost:9090
http://localhost:9090
http://localhost:9090



src/
├── main/
│   ├── java/
│   │   └── com/example/demo/
│   │       ├── controller/
│   │       ├── model/
│   │       └── data/           # Shared DataStore
│   └── resources/
│       ├── templates/
│       │   ├── author/
│       │   └── book/
│       └── css/









📌 Technologies
Spring Boot

Thymeleaf

Java 21

Maven

In-memory data (no database)

Created By
Omar Abu Salem
Spring Boot Homework 2025


