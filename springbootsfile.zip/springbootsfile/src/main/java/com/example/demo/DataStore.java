package com.example.demo.data;

import com.example.demo.model.Author;
import com.example.demo.model.Book;

import java.util.ArrayList;
import java.util.List;

public class DataStore {
    public static List<Author> authors = new ArrayList<>();
    public static List<Book> books = new ArrayList<>();

    static {
        Author orwell = new Author(1L, "George Orwell");
        Author austen = new Author(2L, "Jane Austen");
        authors.add(orwell);
        authors.add(austen);

        books.add(new Book(1L, "1984", orwell));
        books.add(new Book(2L, "Pride and Prejudice", austen));
    }
}
