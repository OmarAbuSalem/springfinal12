package com.example.demo.controller;

import com.example.demo.model.Author;
import com.example.demo.model.Book;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.example.demo.data.DataStore.authors;
import static com.example.demo.data.DataStore.books;

@Controller
public class BookController {

    public BookController() {
        if (authors.isEmpty()) {
            authors.add(new Author(1L, "George Orwell"));
            authors.add(new Author(2L, "Jane Austen"));

            books.add(new Book(1L, "1984", authors.get(0)));
            books.add(new Book(2L, "Pride and Prejudice", authors.get(1)));
        }
    }

    @GetMapping("/books")
    public String getAllBooks(Model model) {
        model.addAttribute("books", books);
        return "book/list";
    }

    @GetMapping("/books/new")
    public String showAddBookForm(Model model) {
        model.addAttribute("book", new Book());
        model.addAttribute("authors", authors);
        return "book/add";
    }

    @PostMapping("/books")
    public String addBook(@ModelAttribute Book book, @RequestParam Long authorId) {
        Author selectedAuthor = authors.stream()
                .filter(a -> a.getId().equals(authorId))
                .findFirst()
                .orElse(null);

        book.setId((long) (books.size() + 1));
        book.setAuthor(selectedAuthor);
        books.add(book);
        return "redirect:/books";
    }

    @GetMapping("/books/{id}")
    public String viewBookDetails(@PathVariable Long id, Model model) {
        Book book = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElse(null);

        model.addAttribute("book", book);
        return "book/details";
    }

    @GetMapping("/books/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Book book = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElse(null);

        model.addAttribute("book", book);
        model.addAttribute("authors", authors);
        return "book/editbook";
    }

    @PostMapping("/books/update/{id}")
    public String updateBook(@PathVariable Long id, @ModelAttribute Book updatedBook, @RequestParam Long authorId) {
        Book existingBook = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (existingBook != null) {
            existingBook.setTitle(updatedBook.getTitle());
            Author selectedAuthor = authors.stream()
                    .filter(a -> a.getId().equals(authorId))
                    .findFirst()
                    .orElse(null);
            existingBook.setAuthor(selectedAuthor);
        }

        return "redirect:/books";
    }

    @GetMapping("/books/delete/{id}")
    public String deleteBook(@PathVariable Long id) {
        books.removeIf(b -> b.getId().equals(id));
        return "redirect:/books";
    }
}
