package com.example.demo.controller;

import com.example.demo.model.Author;
import com.example.demo.model.Book;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.example.demo.data.DataStore.authors;
import static com.example.demo.data.DataStore.books;

@Controller
public class AuthorController {

    @GetMapping("/authors")
    public String getAllAuthors(Model model) {
        model.addAttribute("authors", authors);
        return "author/list";
    }

    @GetMapping("/authors/new")
    public String showAddAuthorForm(Model model) {
        model.addAttribute("author", new Author());
        return "author/add";
    }

    @PostMapping("/authors")
    public String addAuthor(@ModelAttribute Author author) {
        author.setId((long) (authors.size() + 1));
        authors.add(author);
        return "redirect:/authors";
    }

    @GetMapping("/authors/{id}")
    public String viewAuthorDetails(@PathVariable Long id, Model model) {
        Author author = authors.stream()
                .filter(a -> a.getId().equals(id))
                .findFirst()
                .orElse(null);

        List<Book> authorBooks = books.stream()
                .filter(b -> b.getAuthor().getId().equals(id))
                .toList();

        model.addAttribute("author", author);
        model.addAttribute("books", authorBooks);
        return "author/details";
    }

    @GetMapping("/authors/edit/{id}")
    public String showEditAuthorForm(@PathVariable Long id, Model model) {
        Author author = authors.stream()
                .filter(a -> a.getId().equals(id))
                .findFirst()
                .orElse(null);

        model.addAttribute("author", author);
        return "author/editAuthor";
    }

    @PostMapping("/authors/update/{id}")
    public String updateAuthor(@PathVariable Long id, @ModelAttribute Author updatedAuthor) {
        Author existing = authors.stream()
                .filter(a -> a.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (existing != null) {
            existing.setName(updatedAuthor.getName());
        }

        return "redirect:/authors";
    }

    @GetMapping("/authors/delete/{id}")
    public String deleteAuthor(@PathVariable Long id) {
        authors.removeIf(a -> a.getId().equals(id));
        return "redirect:/authors";
    }
}
